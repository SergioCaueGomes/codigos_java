package br.com.rd.queroserdev.mvc.loja.model;

public enum StatusPedido {
	AGUARDANDO, APROVADO, ENTREGUE;
}
