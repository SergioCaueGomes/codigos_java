package com.dev.sergio.springb.userdept;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserdeptApplicationTests {

	@Test
	void contextLoads() {
	}

}
