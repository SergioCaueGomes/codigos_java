package br.com.rd.queroserdev.dao;

public class ClienteDAO {
	
	public void cadastrar() {
		
	}
	
	public buscarPorId() {
		
	}
}
