package br.com.rd.queroserdev.dao;

public class PedidoDAO {
	
	public void cadastrar() {
		
	}
	
	public BigDecimal valorTotalVendido() {
		
	}
	
	public buscarPedidoComCliente() {
		
	}
}
