package br.com.rd.queroserdev.sergio.loja.lojaSergios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LojaSergiosApplicationTests {

	@Test
	void contextLoads() {
	}

}
